
<div class="footer">
    <div class="container ">
        

        <div class="row last_footer_border ">
            <div class="col-lg-7 col-md-12 col-sm-12">
                <div class="footer_last_text">
                    <p>All right reserved. <a href="">sahacpa.ca</a> Designed and Developed by  <a href="https://www.aniyanetworks.net">Aniya Network Solutions Inc.</a>. </p>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->startSection('footer_script'); ?>
<?php if(session('success')): ?>

<script>
  Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: '<?php echo e(session('success')); ?>',
  showConfirmButton: false,
  timer: 1500
})
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/frontend/footer.blade.php ENDPATH**/ ?>