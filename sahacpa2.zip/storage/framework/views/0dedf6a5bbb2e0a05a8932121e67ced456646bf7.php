<footer class="main-footer">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-start justify-content-lg-start justify-content-md-start justify-content-center">
                                <p class="text-gradient-02">Design By
                                <a href="<?php echo e(url('https://www.aniyanetworks.net')); ?>">Aniya Network Solutions Inc.</a></p>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-end justify-content-lg-end justify-content-md-end justify-content-center">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="documentation.html"></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="changelog.html"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </footer>

                    <style>
                        footer {
                            position:fixed;
                            bottom:0;
                            width:88%;
                            height:60px;   /* Height of the footer */
                            background:#000;
                            cursor: pointer;
                            padding: 15px 20px;                   
                            }
                    </style><?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>