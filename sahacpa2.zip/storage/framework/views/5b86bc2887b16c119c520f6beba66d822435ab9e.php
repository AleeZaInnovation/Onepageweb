

<?php $__env->startSection('content'); ?>
                <!-- End Left Sidebar -->
                  <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Manage Menu</h2>
	                                <div>
			                            <ul class="breadcrumb">
			                                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><i class="ti ti-home"></i></a></li>
			                                <li class="breadcrumb-item"><a href="<?php echo e(url('menu.view')); ?>">Menu</a></li>
			                                <li class="breadcrumb-item active">Edit Menu</li>
			                            </ul>
	                                </div>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <div class="row flex-row">
                            <div class="col-12">
                                <!-- Form -->
                                <div class="widget has-shadow">
                                    <div class="page-header-tools">
                                        <a class="btn btn-gradient-01" href="<?php echo e(route('menu.view')); ?>"> Menu List</a>
                                    </div>
                                    <div class="widget-body">
                                        <form class="form-horizontal" method="post" action="<?php echo e(route('menu.update', $edits->id)); ?>" id="myForm" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group row d-flex align-items-center mb-5">
                                                <label class="col-lg-3 form-control-label">Title</label>
                                                <div class="col-lg-9">
                                                    <input type="text" name="title" placeholder="Write title here" value="<?php echo e($edits->title); ?>"class="form-control">
                                                    <font style="color: red;"><?php echo e(($errors->has('title'))?($errors->first('title')):''); ?></font>
                                                </div>
                                            </div>
                                            <div class="form-group row d-flex align-items-center mb-5">
                                            <div class="col-lg-9">
                                            </div>
                                            <div class="col-lg-3">
                                                    <input type="submit" value="Update" class=" btn btn-warning btn-block">
                                                    </div> 
                                            </div>          
                                        </form>
                                    </div>
                                </div>
                                <!-- End Form -->
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
<?php $__env->stopSection(); ?>
      
<?php echo $__env->make('backend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/backend/menu/edit.blade.php ENDPATH**/ ?>