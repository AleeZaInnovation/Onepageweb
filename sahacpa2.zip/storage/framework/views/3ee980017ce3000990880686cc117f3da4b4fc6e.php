

<?php $__env->startSection('content'); ?>
                <!-- End Left Sidebar -->
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Manage Faq</h2>
	                                <div>
			                            <ul class="breadcrumb">
			                                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><i class="ti ti-home"></i></a></li>
			                                <li class="breadcrumb-item active">Blocks</li>
			                            </ul>
	                                </div>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <?php if(Auth::User()->usertype=='Admin'): ?>
                                    <div class="page-header-tools">
	                                    <a class="btn btn-gradient-01" href="<?php echo e(route('addfaq')); ?>">Add Faq</a>
	                                  </div>
                                    <?php endif; ?>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th  >SL.</th>

                                                        <th >Description</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <tr>
                                                        <td><?php echo e($key+1); ?></td>
                                                        <td><?php echo $faq->description; ?></td>
                                                        <td>
                                                             <a href="<?php echo e(route('edit.faq',$faq->id)); ?>" class="btn btn-sm btn-success mb-2">Edit</a>
                                                            <a href="<?php echo e(route('del.faq',$faq->id)); ?>" class="btn btn-sm btn-danger">Del</a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/backend/faq/index.blade.php ENDPATH**/ ?>