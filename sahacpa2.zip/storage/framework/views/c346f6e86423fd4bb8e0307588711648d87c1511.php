
<?php $__env->startSection('content'); ?>
<?php
$blog = App\Models\Blogs::all();
$logo = App\Models\Logo::get()->first();
$banner = App\Models\Banner::get()->first();
$SM = App\Models\SocialMedia::all();
$contact = App\Models\Contact::get()->first();
$menus = App\Models\Menu::all();
?>



    <div class="header_menu">
      <div class="shows">
        <div class="rotate">
            <i class="fa-solid fa-xmark"></i>
        </div>
      </div>
      <div class="menu_part">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
              
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto  mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Dropdown
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="#">Action</a></li>
                      <li><a class="dropdown-item" href="#">Another action</a></li>
                      <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link " href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                  </li>
                </ul>
                
              </div>
            </div>
          </nav>
    </div>
    </div>
</div>
</div>


 

<section class="accounting">
<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
         <img  src= "<?php echo e((!empty($logo->image))?url('assets/backend/images/blogs/'.$logo->image):url('assets/backend/no_image.jpg')); ?>"   alt="mainlogo" class="img-fluid">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
 
      <span class="navbar-toggler-icon"></span>
    </button>
    <?php if($menus != null): ?>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
          <a class="nav-link" id="<?php echo e($item->id); ?>" href="#Block-<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
          <a class="nav-link" href="#ModalFour" data-bs-toggle="modal" data-bs-target="#ModalFour">FAQ</a>
        </li>
      </ul>
    </div>
    <?php else: ?>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link" href="#Block-<?php echo e($blog[0]['id']); ?>">Doctors Accounting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#Block-<?php echo e($blog[1]['id']); ?>">Broker Accounting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#Block-<?php echo e($blog[2]['id']); ?>">Lawyer Accounting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#Block-<?php echo e($blog[3]['id']); ?>">Business accounting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#Block-<?php echo e($blog[4]['id']); ?>">Taxes at Death</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#ModalFour" data-bs-toggle="modal" data-bs-target="#ModalFour">FAQ</a>
        </li>
      </ul>
    </div>
    <?php endif; ?>
  </div>
</nav>
  
   <div class="accounting_part">
   <div class="container-fluid ">
    <div class="row">
      <div  class="accounting_img">
        <img  class="img-fluid" src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[0]['image'])); ?>" alt="">
      </div>
       <div class="accounting_text">
         <div class="covid_text accounting_text_paragraph">
           <h3><?php echo e($blog[0]['title']); ?> </h3>
           <p><?php echo e($blog[0]['summary']); ?></p>
         </div>
      </div>
    </div>
   </div>
   </div>
</section>



<section class="doctors"  id="Block-<?php echo e($blog[0]['id']); ?>">
  <div class="doctors_part d-flex">
    <div class="doctors_text_part">
      <div class="doctors_text">
        <h3><?php echo e($blog[1]['title']); ?> </h3>
        <p><?php echo e($blog[1]['summary']); ?>  </p>
        <div class="btn_part d-flex mt-3" >
         <a href="#contact_us" class="doctors_btn me-3">Contact us      <i class="fa-regular fa-comments icontact"></i></a>
         <a href="" class="doctors_btn_two"    data-bs-toggle="modal" data-bs-target="#ModalBanner">Learn more <i class="fa-solid fa-arrow-right me-2 ilearn"></i></a>
        </div>
     </div>
    </div>
    <div class="doctors_img">
      <img class="img-fluid" src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[1]['image'])); ?>" alt="">
    </div>
  </div>
</section>


<section class="doctors"id="Block-<?php echo e($blog[1]['id']); ?>">
  <div class="doctors_part d-flex">
    <div class="doctors_img">
      <img class="img-fluid" src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[2]['image'])); ?>" alt="">
    </div>
    <div class="doctors_text_part">
      <div class="doctors_text">
        <h3><?php echo e($blog[2]['title']); ?> </h3>
       <p><?php echo e($blog[2]['summary']); ?>  </p>
       <div class="btn_part d-flex mt-3" >
        <a href="#contact_us" class="doctors_btn me-3" >Contact us <i class="fa-regular fa-comments icontact"></i></a>
         <a href="" class="doctors_btn_two"    data-bs-toggle="modal" data-bs-target="#ModalOne">Learn more <i class="fa-solid fa-arrow-right me-2 ilearn"></i></a>
       </div>
    </div>
    </div>
  </div>
</section>


<section class="doctors" id="Block-<?php echo e($blog[2]['id']); ?>">
  <div class="doctors_part d-flex">
    <div class="doctors_img">
      <img class="img-fluid" src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[3]['image'])); ?>" alt="">
    </div>
    <div class="doctors_text_part acconting_color">
      <div class="doctors_text">
        <h3><?php echo e($blog[3]['title']); ?> </h3>
        <p><?php echo e($blog[3]['summary']); ?>  </p>
        <div class="btn_part d-flex mt-3" >
         <a href="#contact_us" class="doctors_btn me-3" >Contact us <i class="fa-regular fa-comments icontact"></i></a>
          <a href="" class="doctors_btn_two"    data-bs-toggle="modal" data-bs-target="#ModalTwo">Learn more <i class="fa-solid fa-arrow-right me-2 ilearn"></i></a>
        </div>
    </div>
    </div>
  </div>
</section>


<section class="doctors" id="Block-<?php echo e($blog[3]['id']); ?>">
  <div class="doctors_part d-flex">
    <div class="doctors_text_part">
      <div class="doctors_text">
        <h3><?php echo e($blog[4]['title']); ?> </h3>
       <p><?php echo e($blog[4]['summary']); ?>  </p>
       <div class="btn_part d-flex mt-3" >
         <a href="#contact_us" class="doctors_btn me-3" >Contact us <i class="fa-regular fa-comments icontact"></i></a>
         <a href="" class="doctors_btn_two"    data-bs-toggle="modal" data-bs-target="#ModalThree">Learn more <i class="fa-solid fa-arrow-right me-2 ilearn"></i></a>
       </div>
    </div>
    </div>
    <div class="doctors_img">
      <img class="img-fluid"  src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[4]['image'])); ?>" alt="">
    </div>
  </div>
</section>


<section class="doctors" id="Block-<?php echo e($blog[4]['id']); ?>">
  <div class="doctors_part d-flex">
    <div class="doctors_img">
      <img class="img-fluid" src="<?php echo e(asset('assets/backend/images/blogs/'.$blog[5]['image'])); ?>" alt="">
    </div>
    <div class="doctors_text_part">
      <div class="doctors_text">
        <h3><?php echo e($blog[5]['title']); ?> </h3>
        <p><?php echo e($blog[5]['summary']); ?>  </p>
        <div class="btn_part d-flex mt-3" >
         <a href="#contact_us" class="doctors_btn me-3" >Contact us <i class="fa-regular fa-comments icontact"></i></a>
          <a href="" class="doctors_btn_two"    data-bs-toggle="modal" data-bs-target="#Modalfive">Learn more <i class="fa-solid fa-arrow-right me-2 ilearn"></i></a>
        </div>
    </div>
    </div>
  </div>
</section>


<section class="contact" id="contact_us">
    <div class="contact_head">
      <h3 class="text-center">Contact</h3>
    </div>
    <div class="contact_part d-flex justify-content-between">
      <div class="contact_info">
        <div class="contact_info_text">
            <?php if($contact !=null): ?>
           <h3>Contact information</h3>
           <p>Fill up the form, our team will contact with you within 24 hours.</p>
           <h5 class="mt-2"><i class="fa-solid fa-phone me-3"></i><?php echo e($contact->mobile); ?></h5>
           <h5 class="mt-2"><i class="fa-regular fa-message me-3"></i><?php echo e($contact->email); ?></h5>
           <div class="location d-flex">
            <h6 class="mt-2"><i class="fa-solid fa-location-dot "></i> </h6>
            <h5 class="mt-2"><?php echo e($contact->address); ?></h5>
            <?php else: ?>
            <h3>Contact information</h3>
              <p>Fill up the form, our team will contact with you within 24 hours.</p>
              <h5 class="mt-2"><i class="fa-solid fa-phone me-3"></i>+416 855 9033</h5>
              <h5 class="mt-2"><i class="fa-regular fa-message me-3"></i>Info@Shahacpa.Ca</h5>
              <div class="location d-flex">
              <h6 class="mt-2"><i class="fa-solid fa-location-dot "></i> </h6>
              <h5 class="mt-2">2 Bloor St W Swite 700
              <span >Toranto, ON M4W 3E2, Canada</span></h5>
            <?php endif; ?>
           </div>
           <div class="footer_logo other_logo mt-3">
                    <img class="img-fluid" src="<?php echo e((!empty($logo->image))?url('assets/backend/images/blogs/'.$logo->image):url('assets/backend/no_image.jpg')); ?>" alt="mainlogo">
                     <h4>Follow us :</h4>
                    </div>
           <div class="contact_social d-flex">
            <?php if($SM[0]!=null): ?>
            <div class="social_item">
              <a href="<?php echo e(($SM[0]['link'])); ?>" class="facebook"><i class="fa-brands fa-facebook-f"></i></a>              
            </div>
            <?php else: ?>
            <div class="social_item">
              <a href="#" class="facebook"><i class="fa-brands fa-facebook-f"></i></a>              
            </div>
            <?php endif; ?>
            <?php if($SM[1]!=null): ?>
            <div class="social_item">
              <a href="<?php echo e(($SM[1]['link'])); ?>"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <?php else: ?>
            <div class="social_item">
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <?php endif; ?>
            <?php if($SM[2]!=null): ?>
            <div class="social_item">
              <a href="<?php echo e(($SM[2]['link'])); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
            <?php else: ?>
            <div class="social_item">
              <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
            <?php endif; ?>
            <?php if($SM[3]!=null): ?>
            <div class="social_item">
              <a href="<?php echo e(($SM[3]['link'])); ?>"><i class="fa-brands fa-instagram"></i></a>
            </div>
            <?php else: ?>
            <div class="social_item">
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
            </div>
            <?php endif; ?>
            <?php if($SM[4]!=null): ?>
            <div class="social_item">
              <a href="<?php echo e(($SM[4]['link'])); ?>" class="youtube"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <?php else: ?>
            <div class="social_item">
              <a href="#" class="youtube"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <?php endif; ?>
           </div>
           <div class="others_img ">
            <img width="160" class="img-fluid" src="<?php echo e(asset('/frontend/image/Ellipse 1 (1).png')); ?>" alt="">
            <div class="round_img">
              <img width="130" class="img-fluid" src="<?php echo e(asset('/frontend/image/Ellipse 2.png')); ?>" alt="">
            </div>
           </div>

        </div>
      </div>
      <div class="contact_form" >
        <form action="<?php echo e(route('add.customer')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                   <div class="col-lg-6">
            <div class="contact_form_item">
              <div class="mt-3">
                <label for="" class="form-label">First name</label>
                <input type="text" name="customer_name" class="form-control" placeholder="Your first name">
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="contact_form_item">
              <div class="mt-3">
                <label for="" class="form-label">Last name</label>
                <input type="text" name="last_name" class="form-control" placeholder="Your last name">
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="contact_form_item">
              <div class="mt-3">
                <label for="" class="form-label">Email Address</label>
                <input type="email" name="customer_email" class="form-control" placeholder="youremail@gmail.com">
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="contact_form_item">
              <div class="mt-3">
                <label for="" class="form-label">Phone Number</label>
                <input type="number"  name="phone" class="form-control" placeholder="your phone number">
              </div>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="contact_form_item">
              <div class="mt-3">
                <label for="" class="form-label">Your Thoughts</label>
                 <textarea  name="customer_msg" placeholder="your Thoughts" class="form-control" cols="20" rows="5"></textarea>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-12 col-sm-12">
            <div class="contact_form_item">
              <div class="mt-3">
                <div  class="mt-3" >
                  <button type="submit" class="btn  docts_send_msg">Send Message</button>
                 </div>
              </div>
            </div>
          </div>
            </div>
        </form>
      </div>
    </div>
</section>








 
    
 
 
 
 
 

 
 
 
 
 <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_one', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_three', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_four', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('frontend.modal_five', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_script'); ?>
<?php if(session('success')): ?>

<script>

 Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: '<?php echo e(session('success')); ?>',
  showConfirmButton: false,
  timer: 1500
})
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/frontend/index_two.blade.php ENDPATH**/ ?>