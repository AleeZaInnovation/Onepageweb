
<?php
$blog = App\Models\Blogs::all();
?>

<div class="modal fade" id="ModalBanner" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header mb-4" style="background: #F2A12B;color:#fff">
        <h5 class="modal-title ps-4" id="exampleModalToggleLabel" ><?php echo e($blog[1]['title']); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
              <div class="text_modal">
                <p><?php echo e($blog[1]['description']); ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer d-flex align-items-end m-4">
        
        <button class="btn btn-danger" data-bs-target="#exampleModalToggle" data-bs-toggle="modal" data-bs-dismiss="modal">Close</button>


      </div>
    </div>
  </div>
</div>





<?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/frontend/modal_banner.blade.php ENDPATH**/ ?>