

<?php $__env->startSection('content'); ?>
                <!-- End Left Sidebar -->
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Manage Users</h2>
	                                <div>
			                            <ul class="breadcrumb">
			                                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>"><i class="ti ti-home"></i></a></li>
			                                <li class="breadcrumb-item active">Users</li>
			                            </ul>
	                                </div>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="page-header-tools">
	                                    <a class="btn btn-gradient-01" href="<?php echo e(route('user.add')); ?>">Add User</a>
	                                </div>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                      <th>SL.</th>
                                                      <th>Role</th>
                                                      <th>Name</th>
                                                      <th>Email</th>
                                                      <th>Number</th>
                                                      <th>Designation</th>
                                                      <th>Address</th>
                                                      <th>Gender</th>
                                                      <th>Image</th>
                                                      <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                    <td><?php echo e($key+1); ?></td>
                                                    <td><?php echo e($user->usertype); ?></td>
                                                    <td><?php echo e($user->name); ?></td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td><?php echo e($user->mobile); ?></td>
                                                    <td><span style="width:100px;"><span class="badge-text badge-text-small info"><?php echo e($user->designation); ?></span></span></td>
                                                    <td><?php echo e($user->address); ?></td>
                                                    <td><?php echo e($user->gender); ?></td>
                                                    <td>
                                                      <img width="50" style="width: 100px; height: 110px; border:1px; solid:#000;" src="<?php echo e((!empty($user->image))?url('assets/backend/images/'.$user->image):url('assets/backend/no_image.jpg')); ?>">
                                                    </td>
                                                    <td class="td-actions">
                                                      <a title="Edit" href="<?php echo e(route('user.edit', $user->id)); ?>"><i class="la la-edit edit"></i></a>
                                                      <a title="Delete" title="Delete" class="confirmDelete" href="javascript:void(0)" module="user" moduleid="<?php echo e($user['id']); ?>"><i class="la la-close delete"></i></a>
                                                    </td>
                                                  </tr>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
<?php $__env->stopSection(); ?>
      
<?php echo $__env->make('backend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ali\htdocs\sahacpa\sahacpa2\resources\views/backend/usermanage/index.blade.php ENDPATH**/ ?>